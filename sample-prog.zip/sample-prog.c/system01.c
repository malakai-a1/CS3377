#include <stdlib.h>

int main(void)
{
	system("ls");
	exit(0);
}
